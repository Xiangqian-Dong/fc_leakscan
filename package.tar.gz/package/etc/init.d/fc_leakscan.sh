#! /bin/sh

export PATH=$PATH:/srv/bin
export LOG4C_RCPATH=/srv/bin

/srv/bin/fc-leakscan -d
sleep 1

exit 0
